﻿namespace ProyRestMatrizArray
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btnMesa1 = new System.Windows.Forms.Button();
            this.btnMesa2 = new System.Windows.Forms.Button();
            this.btnMesa3 = new System.Windows.Forms.Button();
            this.btnMesa4 = new System.Windows.Forms.Button();
            this.btnMesa5 = new System.Windows.Forms.Button();
            this.btnMesa6 = new System.Windows.Forms.Button();
            this.btnMesa7 = new System.Windows.Forms.Button();
            this.btnMesa8 = new System.Windows.Forms.Button();
            this.btnMesa9 = new System.Windows.Forms.Button();
            this.btnMesa10 = new System.Windows.Forms.Button();
            this.btnMesa11 = new System.Windows.Forms.Button();
            this.btnMesa12 = new System.Windows.Forms.Button();
            this.btnMesa13 = new System.Windows.Forms.Button();
            this.btnMesa14 = new System.Windows.Forms.Button();
            this.btnMesa15 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelmesa1 = new System.Windows.Forms.Label();
            this.labelmesa15 = new System.Windows.Forms.Label();
            this.labelmesa14 = new System.Windows.Forms.Label();
            this.labelmesa13 = new System.Windows.Forms.Label();
            this.labelmesa12 = new System.Windows.Forms.Label();
            this.labelmesa11 = new System.Windows.Forms.Label();
            this.labelmesa10 = new System.Windows.Forms.Label();
            this.labelmesa9 = new System.Windows.Forms.Label();
            this.labelmesa8 = new System.Windows.Forms.Label();
            this.labelmesa7 = new System.Windows.Forms.Label();
            this.labelmesa6 = new System.Windows.Forms.Label();
            this.labelmesa5 = new System.Windows.Forms.Label();
            this.labelmesa4 = new System.Windows.Forms.Label();
            this.labelmesa3 = new System.Windows.Forms.Label();
            this.labelmesa2 = new System.Windows.Forms.Label();
            this.fecha = new System.Windows.Forms.Label();
            this.hora = new System.Windows.Forms.Label();
            this.horayfecha = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMesa1
            // 
            this.btnMesa1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa1.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa1.Image")));
            this.btnMesa1.Location = new System.Drawing.Point(21, 39);
            this.btnMesa1.Name = "btnMesa1";
            this.btnMesa1.Size = new System.Drawing.Size(169, 144);
            this.btnMesa1.TabIndex = 0;
            this.btnMesa1.UseVisualStyleBackColor = true;
            this.btnMesa1.Click += new System.EventHandler(this.btnMesa1_Click);
            // 
            // btnMesa2
            // 
            this.btnMesa2.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa2.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa2.Image")));
            this.btnMesa2.Location = new System.Drawing.Point(213, 39);
            this.btnMesa2.Name = "btnMesa2";
            this.btnMesa2.Size = new System.Drawing.Size(169, 144);
            this.btnMesa2.TabIndex = 1;
            this.btnMesa2.UseVisualStyleBackColor = true;
            this.btnMesa2.Click += new System.EventHandler(this.BtnMesa2_Click);
            // 
            // btnMesa3
            // 
            this.btnMesa3.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa3.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa3.Image")));
            this.btnMesa3.Location = new System.Drawing.Point(409, 39);
            this.btnMesa3.Name = "btnMesa3";
            this.btnMesa3.Size = new System.Drawing.Size(169, 144);
            this.btnMesa3.TabIndex = 2;
            this.btnMesa3.UseVisualStyleBackColor = true;
            this.btnMesa3.Click += new System.EventHandler(this.btnMesa3_Click);
            // 
            // btnMesa4
            // 
            this.btnMesa4.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa4.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa4.Image")));
            this.btnMesa4.Location = new System.Drawing.Point(592, 39);
            this.btnMesa4.Name = "btnMesa4";
            this.btnMesa4.Size = new System.Drawing.Size(169, 144);
            this.btnMesa4.TabIndex = 3;
            this.btnMesa4.UseVisualStyleBackColor = true;
            this.btnMesa4.Click += new System.EventHandler(this.btnMesa4_Click);
            // 
            // btnMesa5
            // 
            this.btnMesa5.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa5.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa5.Image")));
            this.btnMesa5.Location = new System.Drawing.Point(783, 39);
            this.btnMesa5.Name = "btnMesa5";
            this.btnMesa5.Size = new System.Drawing.Size(169, 144);
            this.btnMesa5.TabIndex = 4;
            this.btnMesa5.UseVisualStyleBackColor = true;
            this.btnMesa5.Click += new System.EventHandler(this.btnMesa5_Click);
            // 
            // btnMesa6
            // 
            this.btnMesa6.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa6.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa6.Image")));
            this.btnMesa6.Location = new System.Drawing.Point(21, 221);
            this.btnMesa6.Name = "btnMesa6";
            this.btnMesa6.Size = new System.Drawing.Size(169, 144);
            this.btnMesa6.TabIndex = 5;
            this.btnMesa6.UseVisualStyleBackColor = true;
            this.btnMesa6.Click += new System.EventHandler(this.btnMesa6_Click);
            // 
            // btnMesa7
            // 
            this.btnMesa7.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa7.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa7.Image")));
            this.btnMesa7.Location = new System.Drawing.Point(213, 221);
            this.btnMesa7.Name = "btnMesa7";
            this.btnMesa7.Size = new System.Drawing.Size(169, 144);
            this.btnMesa7.TabIndex = 6;
            this.btnMesa7.UseVisualStyleBackColor = true;
            this.btnMesa7.Click += new System.EventHandler(this.btnMesa7_Click);
            // 
            // btnMesa8
            // 
            this.btnMesa8.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa8.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa8.Image")));
            this.btnMesa8.Location = new System.Drawing.Point(409, 221);
            this.btnMesa8.Name = "btnMesa8";
            this.btnMesa8.Size = new System.Drawing.Size(169, 144);
            this.btnMesa8.TabIndex = 7;
            this.btnMesa8.UseVisualStyleBackColor = true;
            this.btnMesa8.Click += new System.EventHandler(this.btnMesa8_Click);
            // 
            // btnMesa9
            // 
            this.btnMesa9.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa9.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa9.Image")));
            this.btnMesa9.Location = new System.Drawing.Point(595, 221);
            this.btnMesa9.Name = "btnMesa9";
            this.btnMesa9.Size = new System.Drawing.Size(169, 144);
            this.btnMesa9.TabIndex = 8;
            this.btnMesa9.UseVisualStyleBackColor = true;
            this.btnMesa9.Click += new System.EventHandler(this.btnMesa9_Click);
            // 
            // btnMesa10
            // 
            this.btnMesa10.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa10.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa10.Image")));
            this.btnMesa10.Location = new System.Drawing.Point(783, 221);
            this.btnMesa10.Name = "btnMesa10";
            this.btnMesa10.Size = new System.Drawing.Size(169, 144);
            this.btnMesa10.TabIndex = 9;
            this.btnMesa10.UseVisualStyleBackColor = true;
            this.btnMesa10.Click += new System.EventHandler(this.btnMesa10_Click);
            // 
            // btnMesa11
            // 
            this.btnMesa11.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa11.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa11.Image")));
            this.btnMesa11.Location = new System.Drawing.Point(21, 413);
            this.btnMesa11.Name = "btnMesa11";
            this.btnMesa11.Size = new System.Drawing.Size(169, 144);
            this.btnMesa11.TabIndex = 10;
            this.btnMesa11.UseVisualStyleBackColor = true;
            this.btnMesa11.Click += new System.EventHandler(this.btnMesa11_Click);
            // 
            // btnMesa12
            // 
            this.btnMesa12.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa12.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa12.Image")));
            this.btnMesa12.Location = new System.Drawing.Point(213, 413);
            this.btnMesa12.Name = "btnMesa12";
            this.btnMesa12.Size = new System.Drawing.Size(169, 144);
            this.btnMesa12.TabIndex = 11;
            this.btnMesa12.UseVisualStyleBackColor = true;
            this.btnMesa12.Click += new System.EventHandler(this.btnMesa12_Click);
            // 
            // btnMesa13
            // 
            this.btnMesa13.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa13.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa13.Image")));
            this.btnMesa13.Location = new System.Drawing.Point(409, 413);
            this.btnMesa13.Name = "btnMesa13";
            this.btnMesa13.Size = new System.Drawing.Size(169, 144);
            this.btnMesa13.TabIndex = 12;
            this.btnMesa13.UseVisualStyleBackColor = true;
            this.btnMesa13.Click += new System.EventHandler(this.btnMesa13_Click);
            // 
            // btnMesa14
            // 
            this.btnMesa14.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa14.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa14.Image")));
            this.btnMesa14.Location = new System.Drawing.Point(595, 413);
            this.btnMesa14.Name = "btnMesa14";
            this.btnMesa14.Size = new System.Drawing.Size(169, 144);
            this.btnMesa14.TabIndex = 13;
            this.btnMesa14.UseVisualStyleBackColor = true;
            this.btnMesa14.Click += new System.EventHandler(this.btnMesa14_Click);
            // 
            // btnMesa15
            // 
            this.btnMesa15.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMesa15.Image = ((System.Drawing.Image)(resources.GetObject("btnMesa15.Image")));
            this.btnMesa15.Location = new System.Drawing.Point(783, 413);
            this.btnMesa15.Name = "btnMesa15";
            this.btnMesa15.Size = new System.Drawing.Size(169, 144);
            this.btnMesa15.TabIndex = 14;
            this.btnMesa15.UseVisualStyleBackColor = true;
            this.btnMesa15.Click += new System.EventHandler(this.btnMesa15_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.labelmesa1);
            this.groupBox1.Controls.Add(this.labelmesa15);
            this.groupBox1.Controls.Add(this.labelmesa14);
            this.groupBox1.Controls.Add(this.labelmesa13);
            this.groupBox1.Controls.Add(this.labelmesa12);
            this.groupBox1.Controls.Add(this.labelmesa11);
            this.groupBox1.Controls.Add(this.labelmesa10);
            this.groupBox1.Controls.Add(this.labelmesa9);
            this.groupBox1.Controls.Add(this.labelmesa8);
            this.groupBox1.Controls.Add(this.labelmesa7);
            this.groupBox1.Controls.Add(this.labelmesa6);
            this.groupBox1.Controls.Add(this.labelmesa5);
            this.groupBox1.Controls.Add(this.labelmesa4);
            this.groupBox1.Controls.Add(this.labelmesa3);
            this.groupBox1.Controls.Add(this.labelmesa2);
            this.groupBox1.Controls.Add(this.btnMesa1);
            this.groupBox1.Controls.Add(this.btnMesa15);
            this.groupBox1.Controls.Add(this.btnMesa2);
            this.groupBox1.Controls.Add(this.btnMesa14);
            this.groupBox1.Controls.Add(this.btnMesa3);
            this.groupBox1.Controls.Add(this.btnMesa13);
            this.groupBox1.Controls.Add(this.btnMesa4);
            this.groupBox1.Controls.Add(this.btnMesa12);
            this.groupBox1.Controls.Add(this.btnMesa5);
            this.groupBox1.Controls.Add(this.btnMesa11);
            this.groupBox1.Controls.Add(this.btnMesa6);
            this.groupBox1.Controls.Add(this.btnMesa10);
            this.groupBox1.Controls.Add(this.btnMesa7);
            this.groupBox1.Controls.Add(this.btnMesa9);
            this.groupBox1.Controls.Add(this.btnMesa8);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Location = new System.Drawing.Point(33, 67);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(960, 581);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MESAS";
            this.groupBox1.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // labelmesa1
            // 
            this.labelmesa1.AutoSize = true;
            this.labelmesa1.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa1.Location = new System.Drawing.Point(76, 186);
            this.labelmesa1.Name = "labelmesa1";
            this.labelmesa1.Size = new System.Drawing.Size(64, 17);
            this.labelmesa1.TabIndex = 30;
            this.labelmesa1.Text = "MESA 1";
            // 
            // labelmesa15
            // 
            this.labelmesa15.AutoSize = true;
            this.labelmesa15.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa15.Location = new System.Drawing.Point(829, 560);
            this.labelmesa15.Name = "labelmesa15";
            this.labelmesa15.Size = new System.Drawing.Size(70, 16);
            this.labelmesa15.TabIndex = 29;
            this.labelmesa15.Text = "MESA 15";
            // 
            // labelmesa14
            // 
            this.labelmesa14.AutoSize = true;
            this.labelmesa14.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa14.Location = new System.Drawing.Point(645, 560);
            this.labelmesa14.Name = "labelmesa14";
            this.labelmesa14.Size = new System.Drawing.Size(70, 16);
            this.labelmesa14.TabIndex = 28;
            this.labelmesa14.Text = "MESA 14";
            // 
            // labelmesa13
            // 
            this.labelmesa13.AutoSize = true;
            this.labelmesa13.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa13.Location = new System.Drawing.Point(454, 560);
            this.labelmesa13.Name = "labelmesa13";
            this.labelmesa13.Size = new System.Drawing.Size(70, 16);
            this.labelmesa13.TabIndex = 27;
            this.labelmesa13.Text = "MESA 13";
            // 
            // labelmesa12
            // 
            this.labelmesa12.AutoSize = true;
            this.labelmesa12.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa12.Location = new System.Drawing.Point(261, 560);
            this.labelmesa12.Name = "labelmesa12";
            this.labelmesa12.Size = new System.Drawing.Size(70, 16);
            this.labelmesa12.TabIndex = 26;
            this.labelmesa12.Text = "MESA 12";
            // 
            // labelmesa11
            // 
            this.labelmesa11.AutoSize = true;
            this.labelmesa11.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa11.Location = new System.Drawing.Point(76, 560);
            this.labelmesa11.Name = "labelmesa11";
            this.labelmesa11.Size = new System.Drawing.Size(70, 16);
            this.labelmesa11.TabIndex = 25;
            this.labelmesa11.Text = "MESA 11";
            // 
            // labelmesa10
            // 
            this.labelmesa10.AutoSize = true;
            this.labelmesa10.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa10.Location = new System.Drawing.Point(829, 368);
            this.labelmesa10.Name = "labelmesa10";
            this.labelmesa10.Size = new System.Drawing.Size(70, 16);
            this.labelmesa10.TabIndex = 24;
            this.labelmesa10.Text = "MESA 10";
            // 
            // labelmesa9
            // 
            this.labelmesa9.AutoSize = true;
            this.labelmesa9.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa9.Location = new System.Drawing.Point(645, 368);
            this.labelmesa9.Name = "labelmesa9";
            this.labelmesa9.Size = new System.Drawing.Size(62, 16);
            this.labelmesa9.TabIndex = 23;
            this.labelmesa9.Text = "MESA 9";
            // 
            // labelmesa8
            // 
            this.labelmesa8.AutoSize = true;
            this.labelmesa8.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa8.Location = new System.Drawing.Point(462, 368);
            this.labelmesa8.Name = "labelmesa8";
            this.labelmesa8.Size = new System.Drawing.Size(62, 16);
            this.labelmesa8.TabIndex = 22;
            this.labelmesa8.Text = "MESA 8";
            // 
            // labelmesa7
            // 
            this.labelmesa7.AutoSize = true;
            this.labelmesa7.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa7.Location = new System.Drawing.Point(269, 368);
            this.labelmesa7.Name = "labelmesa7";
            this.labelmesa7.Size = new System.Drawing.Size(62, 16);
            this.labelmesa7.TabIndex = 21;
            this.labelmesa7.Text = "MESA 7";
            // 
            // labelmesa6
            // 
            this.labelmesa6.AutoSize = true;
            this.labelmesa6.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa6.Location = new System.Drawing.Point(76, 368);
            this.labelmesa6.Name = "labelmesa6";
            this.labelmesa6.Size = new System.Drawing.Size(62, 16);
            this.labelmesa6.TabIndex = 20;
            this.labelmesa6.Text = "MESA 6";
            // 
            // labelmesa5
            // 
            this.labelmesa5.AutoSize = true;
            this.labelmesa5.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa5.Location = new System.Drawing.Point(837, 186);
            this.labelmesa5.Name = "labelmesa5";
            this.labelmesa5.Size = new System.Drawing.Size(62, 16);
            this.labelmesa5.TabIndex = 19;
            this.labelmesa5.Text = "MESA 5";
            // 
            // labelmesa4
            // 
            this.labelmesa4.AutoSize = true;
            this.labelmesa4.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa4.Location = new System.Drawing.Point(645, 186);
            this.labelmesa4.Name = "labelmesa4";
            this.labelmesa4.Size = new System.Drawing.Size(62, 16);
            this.labelmesa4.TabIndex = 18;
            this.labelmesa4.Text = "MESA 4";
            // 
            // labelmesa3
            // 
            this.labelmesa3.AutoSize = true;
            this.labelmesa3.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa3.Location = new System.Drawing.Point(462, 186);
            this.labelmesa3.Name = "labelmesa3";
            this.labelmesa3.Size = new System.Drawing.Size(62, 16);
            this.labelmesa3.TabIndex = 17;
            this.labelmesa3.Text = "MESA 3";
            // 
            // labelmesa2
            // 
            this.labelmesa2.AutoSize = true;
            this.labelmesa2.BackColor = System.Drawing.Color.Transparent;
            this.labelmesa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmesa2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelmesa2.Location = new System.Drawing.Point(267, 185);
            this.labelmesa2.Name = "labelmesa2";
            this.labelmesa2.Size = new System.Drawing.Size(64, 17);
            this.labelmesa2.TabIndex = 16;
            this.labelmesa2.Text = "MESA 2";
            // 
            // fecha
            // 
            this.fecha.AutoSize = true;
            this.fecha.BackColor = System.Drawing.Color.Transparent;
            this.fecha.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecha.ForeColor = System.Drawing.Color.White;
            this.fecha.Location = new System.Drawing.Point(41, 9);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(69, 29);
            this.fecha.TabIndex = 16;
            this.fecha.Text = "Fecha";
            // 
            // hora
            // 
            this.hora.AutoSize = true;
            this.hora.BackColor = System.Drawing.Color.Transparent;
            this.hora.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hora.ForeColor = System.Drawing.Color.White;
            this.hora.Location = new System.Drawing.Point(551, 9);
            this.hora.Name = "hora";
            this.hora.Size = new System.Drawing.Size(60, 29);
            this.hora.TabIndex = 17;
            this.hora.Text = "Hora";
            // 
            // horayfecha
            // 
            this.horayfecha.Enabled = true;
            this.horayfecha.Tick += new System.EventHandler(this.Horayfecha_Tick);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::ProyRestMatrizArray.Properties.Resources.triangle_abstract_gradient_soft_gradient_wallpaper_preview;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(781, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 39);
            this.button1.TabIndex = 18;
            this.button1.Text = "Cerrar sesión";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::ProyRestMatrizArray.Properties.Resources.triangle_abstract_gradient_soft_gradient_wallpaper_preview;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(889, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 39);
            this.button4.TabIndex = 23;
            this.button4.Text = "Historico";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1045, 655);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hora);
            this.Controls.Add(this.fecha);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mesas";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMesa1;
        private System.Windows.Forms.Button btnMesa2;
        private System.Windows.Forms.Button btnMesa3;
        private System.Windows.Forms.Button btnMesa4;
        private System.Windows.Forms.Button btnMesa5;
        private System.Windows.Forms.Button btnMesa6;
        private System.Windows.Forms.Button btnMesa7;
        private System.Windows.Forms.Button btnMesa8;
        private System.Windows.Forms.Button btnMesa9;
        private System.Windows.Forms.Button btnMesa10;
        private System.Windows.Forms.Button btnMesa11;
        private System.Windows.Forms.Button btnMesa12;
        private System.Windows.Forms.Button btnMesa13;
        private System.Windows.Forms.Button btnMesa14;
        private System.Windows.Forms.Button btnMesa15;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label fecha;
        private System.Windows.Forms.Label hora;
        private System.Windows.Forms.Timer horayfecha;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelmesa15;
        private System.Windows.Forms.Label labelmesa14;
        private System.Windows.Forms.Label labelmesa13;
        private System.Windows.Forms.Label labelmesa12;
        private System.Windows.Forms.Label labelmesa11;
        private System.Windows.Forms.Label labelmesa10;
        private System.Windows.Forms.Label labelmesa9;
        private System.Windows.Forms.Label labelmesa8;
        private System.Windows.Forms.Label labelmesa7;
        private System.Windows.Forms.Label labelmesa6;
        private System.Windows.Forms.Label labelmesa5;
        private System.Windows.Forms.Label labelmesa4;
        private System.Windows.Forms.Label labelmesa3;
        private System.Windows.Forms.Label labelmesa2;
        private System.Windows.Forms.Label labelmesa1;
        private System.Windows.Forms.Button button4;
    }
}